<footer class="footer">
    @include('layouts.footers.nav')
</footer>